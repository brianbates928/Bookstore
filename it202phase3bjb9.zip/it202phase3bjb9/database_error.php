<!DOCTYPE html>
<html>
    <!-- slide 23 the head section -->
    <!--Brian Bates it202-001 10/10/22 phase1-->
    <head>
        <title>Book Store</title>
        <link rel="stylesheet" type="text/css" href="main.css">
    </head>
 
    <!-- the body section -->
    <body>
    <main>
        <h1>Database Error</h1>

        <p>Error message: <?php echo $error_message; ?></p>
    </main>
    </body>
</html>
