<!DOCTYPE html>
<!--Brian Bates it202-001 10/10/22 phase1-->
<html lang="en">
<head>
   <meta charset="utf-8">
   <title>Brian's Bookstore</title>
   <link rel="stylesheet" href="style.css">
   <link rel="icon" type="image/x-icon" href="images/b.jpg">

</head>
<body>
    <div class="topnav">
        <a class="active" href="home.html">Home!</a>
        <a href="Create.php">Create!</a>
        <a href="About.html">About us!</a>
        <a href="Contact.php">Contact us!</a>
        <a href="books.php">List all books!</a>
      </div> 
      <h2>Contact us!</h2>
      <div class="grid-container">

<div class="grid-item">
<img src="images/newark.jpg" style="height:400px; width:400px;" alt="Map of US with pin showing Newark"></div>
<div class="grid-item"><p>We are located at 323 Dr Martin Luther King Jr Blvd, Newark, NJ 07102 and we are open from 9am-5pm, 7 days a week!</p></div>
<div class="grid-item"><p>Our phone # is 1234567890 and will answer as long as you call during operation hours!</p>  </div>  
<div class="grid-item"><p>If you can't make it in or call, feel free to email us! Brian's email is <a href = "mailto:bjb9@njit.edu">bjb9@njit.edu</a></p></div>
<div class="grid-item2"><a href="mail.php">Join mailing list!</a></div>
</div>
<footer>Ⓒ Brian's Bookstore 2022  </footer>
</body>
      </html>
      